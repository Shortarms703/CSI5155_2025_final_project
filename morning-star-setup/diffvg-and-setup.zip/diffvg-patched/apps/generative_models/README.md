# Usage

For the GAN models, see `train_gan.py`. Generate samples from a pretrained using `eval_gan.py`

For the VAE models, see `mnist_vae.py`.
